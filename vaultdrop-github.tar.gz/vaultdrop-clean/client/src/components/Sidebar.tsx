import { useLocation, Link } from "wouter";
import { useAuth } from "@/lib/auth";
import { formatBytes, formatDate } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  badge?: string;
  adminOnly?: boolean;
}

const UploadIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
  </svg>
);
const FolderIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 7a2 2 0 012-2h4l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7z" />
  </svg>
);
const DashboardIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 5a1 1 0 011-1h4a1 1 0 011 1v5a1 1 0 01-1 1H5a1 1 0 01-1-1V5zm10 0a1 1 0 011-1h4a1 1 0 011 1v3a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1v-4zm10-2a1 1 0 011-1h4a1 1 0 011 1v6a1 1 0 01-1 1h-4a1 1 0 01-1-1v-6z" />
  </svg>
);
const UsersIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
  </svg>
);
const ChartIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
);
const LogoutIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
  </svg>
);
const ShieldIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
  </svg>
);

function NavLink({ item, active }: { item: NavItem; active: boolean }) {
  return (
    <Link href={item.href}>
      <div
        data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
        className={cn(
          "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm cursor-pointer transition-all group",
          active
            ? "bg-primary/20 text-primary border border-primary/20"
            : "text-sidebar-foreground/70 hover:bg-white/5 hover:text-sidebar-foreground"
        )}
      >
        <span className={cn("flex-shrink-0", active ? "text-primary" : "text-muted-foreground group-hover:text-sidebar-foreground")}>
          {item.icon}
        </span>
        <span className="flex-1">{item.label}</span>
        {item.badge && (
          <span className="text-xs bg-primary/20 text-primary px-1.5 py-0.5 rounded-md font-medium">
            {item.badge}
          </span>
        )}
      </div>
    </Link>
  );
}

export default function Sidebar() {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const isAdmin = user?.role === "admin";

  const storagePercent = Math.min(((user?.storageUsed || 0) / (500 * 1024 * 1024)) * 100, 100);

  const overviewItems: NavItem[] = [
    { label: "Dashboard", href: "/dashboard", icon: <DashboardIcon /> },
  ];

  const fileItems: NavItem[] = [
    { label: "My Files", href: "/dashboard", icon: <FolderIcon /> },
    { label: "Upload", href: "/dashboard?tab=upload", icon: <UploadIcon /> },
  ];

  const adminItems: NavItem[] = [
    { label: "Users", href: "/admin", icon: <UsersIcon />, adminOnly: true },
    { label: "All Files", href: "/admin?tab=files", icon: <FolderIcon />, adminOnly: true },
    { label: "Statistics", href: "/admin?tab=stats", icon: <ChartIcon />, adminOnly: true, badge: "Live" },
  ];

  return (
    <aside className="w-64 h-screen flex flex-col bg-sidebar border-r border-sidebar-border flex-shrink-0 overflow-y-auto">
      {/* Logo */}
      <div className="p-5 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
          </div>
          <div>
            <p className="font-bold text-foreground text-sm tracking-wide">VAULTDROP</p>
            <p className="text-xs text-muted-foreground">File Storage</p>
          </div>
        </div>
      </div>

      {/* Welcome block */}
      <div className="px-5 py-4 border-b border-sidebar-border">
        <p className="text-xs text-muted-foreground mb-0.5">Welcome Back,</p>
        <p className="font-semibold text-foreground text-base">{user?.username}</p>
        {user?.lastLoginAt && (
          <p className="text-xs text-muted-foreground mt-0.5">
            Last login: {formatDate(user.lastLoginAt).split(",")[0]}
          </p>
        )}
        {isAdmin && (
          <div className="mt-2 flex items-center gap-1.5 text-xs text-primary">
            <ShieldIcon />
            <span className="font-medium">Administrator</span>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-5">
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">Overview</p>
          <div className="space-y-1">
            {overviewItems.map(item => (
              <NavLink key={item.href} item={item} active={location === item.href} />
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">Files</p>
          <div className="space-y-1">
            {fileItems.map(item => (
              <NavLink key={item.label} item={item} active={location === item.href && item.label === "My Files"} />
            ))}
          </div>
        </div>

        {isAdmin && (
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">Admin</p>
            <div className="space-y-1">
              {adminItems.map(item => (
                <NavLink key={item.label} item={item} active={location.startsWith("/admin")} />
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Storage indicator */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="glass rounded-xl p-3 mb-3">
          <div className="flex justify-between text-xs mb-2">
            <span className="text-muted-foreground">Storage Used</span>
            <span className="text-foreground font-medium">{formatBytes(user?.storageUsed || 0)}</span>
          </div>
          <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
            <div
              className="h-full rounded-full progress-bar-animated transition-all duration-500"
              style={{ width: `${storagePercent}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-1.5">{storagePercent.toFixed(1)}% of 500 MB</p>
        </div>

        <button
          data-testid="button-logout"
          onClick={logout}
          className="flex items-center gap-2.5 w-full px-3 py-2.5 rounded-xl text-muted-foreground hover:text-red-400 hover:bg-red-400/10 text-sm transition-all"
        >
          <LogoutIcon />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
