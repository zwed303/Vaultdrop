import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { formatBytes, formatDate, getFileIcon } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  username: string;
  email: string;
  role: string;
  storageUsed: number;
  createdAt: string;
  lastLoginAt: string | null;
}

interface FileWithUser {
  id: number;
  userId: number;
  username: string;
  originalName: string;
  size: number;
  mimeType: string;
  isPublic: boolean;
  downloadCount: number;
  uploadedAt: string;
}

interface AdminStats {
  totalUsers: number;
  totalFiles: number;
  totalStorage: number;
  recentUploads: number;
}

type Tab = "overview" | "users" | "files";

export default function AdminPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<Tab>("overview");

  if (!user || user.role !== "admin") {
    setLocation("/dashboard");
    return null;
  }

  const { data: stats } = useQuery<AdminStats>({ queryKey: ["/api/admin/stats"] });
  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    enabled: tab === "users",
  });
  const { data: files = [], isLoading: filesLoading } = useQuery<FileWithUser[]>({
    queryKey: ["/api/admin/files"],
    enabled: tab === "files",
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/users/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({ title: "User deleted", description: "User and their files removed." });
    },
    onError: () => toast({ title: "Error", description: "Failed to delete user.", variant: "destructive" }),
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/files/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/files"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({ title: "File deleted" });
    },
    onError: () => toast({ title: "Error", description: "Failed to delete file.", variant: "destructive" }),
  });

  const tabs = [
    { key: "overview" as Tab, label: "Statistics" },
    { key: "users" as Tab, label: "Users" },
    { key: "files" as Tab, label: "All Files" },
  ];

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />

      <main className="flex-1 overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 z-10 px-8 py-5 border-b border-border/50 bg-background/80 backdrop-blur-md">
          <p className="text-xs text-muted-foreground">Admin / Panel</p>
          <h1 className="text-xl font-bold text-foreground">Admin Dashboard</h1>
        </div>

        <div className="p-8 space-y-8">
          {/* Tabs */}
          <div className="flex gap-1 p-1 glass rounded-xl w-fit">
            {tabs.map(t => (
              <button
                key={t.key}
                data-testid={`tab-${t.key}`}
                onClick={() => setTab(t.key)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  tab === t.key
                    ? "bg-primary/20 text-primary border border-primary/20"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Overview tab */}
          {tab === "overview" && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: "Total Users", value: stats?.totalUsers ?? "—", icon: "👥", color: "text-blue-400" },
                  { label: "Total Files", value: stats?.totalFiles ?? "—", icon: "📁", color: "text-purple-400" },
                  { label: "Total Storage", value: stats ? formatBytes(stats.totalStorage) : "—", icon: "💾", color: "text-violet-400" },
                  { label: "Uploads Today", value: stats?.recentUploads ?? "—", icon: "⬆️", color: "text-green-400" },
                ].map((stat, i) => (
                  <div key={i} data-testid={`card-admin-stat-${i}`} className="glass rounded-2xl p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-xl">{stat.icon}</span>
                      <p className="text-muted-foreground text-xs">{stat.label}</p>
                    </div>
                    <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                ))}
              </div>

              <div className="glass rounded-2xl p-6">
                <h3 className="text-base font-semibold text-foreground mb-4">System Info</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Admin User</span>
                      <span className="text-primary font-medium">{user.username}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Max File Size</span>
                      <span className="text-foreground">500 MB</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Platform Status</span>
                      <span className="text-green-400 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block" />
                        Online
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Storage Avg/User</span>
                      <span className="text-foreground">
                        {stats && stats.totalUsers > 0 ? formatBytes(stats.totalStorage / stats.totalUsers) : "—"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Users tab */}
          {tab === "users" && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-base font-semibold text-foreground">All Users</h2>
                <span className="text-xs bg-white/5 text-muted-foreground px-2.5 py-1 rounded-full">
                  {users.length} users
                </span>
              </div>
              {usersLoading ? (
                <div className="flex justify-center py-16">
                  <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent spin-loader" />
                </div>
              ) : (
                <div className="space-y-2">
                  {users.map(u => (
                    <div
                      key={u.id}
                      data-testid={`card-user-${u.id}`}
                      className="glass rounded-xl px-5 py-4 flex items-center gap-4 group hover:bg-white/[0.04] transition-all"
                    >
                      <div className="w-10 h-10 rounded-xl bg-primary/20 border border-primary/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-primary font-bold text-sm">{u.username[0].toUpperCase()}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-foreground">{u.username}</p>
                          {u.role === "admin" && (
                            <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded font-bold uppercase">
                              Admin
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-0.5">
                          <span className="text-xs text-muted-foreground">{u.email}</span>
                          <span className="text-muted-foreground/40">·</span>
                          <span className="text-xs text-muted-foreground">{formatBytes(u.storageUsed)} used</span>
                          <span className="text-muted-foreground/40">·</span>
                          <span className="text-xs text-muted-foreground">Joined {formatDate(u.createdAt)}</span>
                        </div>
                      </div>
                      {u.role !== "admin" && (
                        <button
                          data-testid={`button-delete-user-${u.id}`}
                          onClick={() => {
                            if (confirm(`Delete user "${u.username}" and all their files?`)) {
                              deleteUserMutation.mutate(u.id);
                            }
                          }}
                          className="opacity-0 group-hover:opacity-100 p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-all"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Files tab */}
          {tab === "files" && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-base font-semibold text-foreground">All Files</h2>
                <span className="text-xs bg-white/5 text-muted-foreground px-2.5 py-1 rounded-full">
                  {files.length} files
                </span>
              </div>
              {filesLoading ? (
                <div className="flex justify-center py-16">
                  <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent spin-loader" />
                </div>
              ) : (
                <div className="space-y-2">
                  {files.map(file => (
                    <div
                      key={file.id}
                      data-testid={`card-admin-file-${file.id}`}
                      className="glass rounded-xl px-5 py-4 flex items-center gap-4 group hover:bg-white/[0.04] transition-all"
                    >
                      <span className="text-xl flex-shrink-0">{getFileIcon(file.mimeType)}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{file.originalName}</p>
                        <div className="flex items-center gap-3 mt-0.5">
                          <span className="text-xs text-primary font-medium">@{file.username}</span>
                          <span className="text-muted-foreground/40">·</span>
                          <span className="text-xs text-muted-foreground">{formatBytes(file.size)}</span>
                          <span className="text-muted-foreground/40">·</span>
                          <span className="text-xs text-muted-foreground">{formatDate(file.uploadedAt)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all">
                        <a
                          href={`/api/files/${file.id}/download`}
                          className="p-2 rounded-lg bg-primary/20 hover:bg-primary/30 text-primary transition-all"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                          </svg>
                        </a>
                        <button
                          data-testid={`button-delete-file-${file.id}`}
                          onClick={() => {
                            if (confirm("Delete this file?")) deleteFileMutation.mutate(file.id);
                          }}
                          className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-all"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
