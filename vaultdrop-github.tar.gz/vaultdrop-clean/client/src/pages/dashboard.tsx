import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import { useAuth } from "@/lib/auth";
import { formatBytes, formatDate, getFileIcon } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface FileRecord {
  id: number;
  userId: number;
  filename: string;
  originalName: string;
  size: number;
  mimeType: string;
  isPublic: boolean;
  downloadCount: number;
  uploadedAt: string;
}

interface UploadState {
  file: File;
  progress: number;
  status: "uploading" | "done" | "error";
}

function UploadProgressCard({ state, onClose }: { state: UploadState; onClose: () => void }) {
  const icon = getFileIcon(state.file.type);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="glass-strong rounded-2xl p-6 w-full max-w-sm mx-4 glow-purple">
        {/* Close */}
        {state.status !== "uploading" && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-foreground transition-all"
            data-testid="button-close-upload"
          >
            ✕
          </button>
        )}

        {/* File info */}
        <div className="flex items-center gap-4 mb-6">
          <div className="relative flex-shrink-0">
            <div className="w-16 h-20 rounded-xl bg-gradient-to-br from-purple-600/30 to-violet-800/30 border border-white/10 flex items-center justify-center">
              <span className="text-2xl">{icon}</span>
            </div>
            <div className="absolute -bottom-1 -right-1 bg-primary/80 text-white text-[9px] font-bold px-1.5 py-0.5 rounded uppercase">
              {state.file.name.split(".").pop() || "FILE"}
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-foreground text-base truncate">{state.file.name}</p>
            <p className="text-muted-foreground text-sm mt-0.5">{formatBytes(state.file.size)}</p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              {state.status === "uploading" && (
                <div className="w-4 h-4 rounded-full border-2 border-primary border-t-transparent spin-loader" />
              )}
              {state.status === "done" && <span className="text-green-400">✓</span>}
              {state.status === "error" && <span className="text-red-400">✗</span>}
              <span>
                {state.status === "uploading" ? "Uploading..." : state.status === "done" ? "Complete!" : "Failed"}
              </span>
            </div>
            <span className="font-semibold text-foreground text-base">{state.progress}%</span>
          </div>

          <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                state.status === "uploading" ? "progress-bar-animated progress-glow" : 
                state.status === "done" ? "bg-green-500" : "bg-red-500"
              }`}
              style={{ width: `${state.progress}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function DropZone({ onFilesSelected }: { onFilesSelected: (files: FileList) => void }) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files.length > 0) {
      onFilesSelected(e.dataTransfer.files);
    }
  }, [onFilesSelected]);

  return (
    <div
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      data-testid="dropzone-upload"
      className={`relative rounded-2xl border-2 border-dashed p-12 text-center cursor-pointer transition-all ${
        dragging
          ? "border-primary/80 bg-primary/10 glow-purple-sm"
          : "border-white/15 hover:border-primary/40 hover:bg-white/[0.02]"
      }`}
    >
      <input
        ref={inputRef}
        type="file"
        multiple
        className="hidden"
        onChange={e => e.target.files && onFilesSelected(e.target.files)}
        data-testid="input-file"
      />
      <div className="flex flex-col items-center gap-4">
        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all ${
          dragging ? "bg-primary/30 glow-purple-sm" : "bg-white/5"
        }`}>
          <svg className={`w-8 h-8 ${dragging ? "text-primary" : "text-muted-foreground"}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
          </svg>
        </div>
        <div>
          <p className="text-lg font-semibold text-foreground">
            {dragging ? "Drop files here" : "Drag & Drop your files"}
          </p>
          <p className="text-muted-foreground text-sm mt-1">or click to browse — max 500MB per file</p>
        </div>
        <div className="flex gap-2 flex-wrap justify-center">
          {["Images", "Videos", "Documents", "Archives"].map(type => (
            <span key={type} className="text-xs bg-white/5 border border-white/10 text-muted-foreground px-3 py-1 rounded-full">
              {type}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [uploadState, setUploadState] = useState<UploadState | null>(null);
  const [search, setSearch] = useState("");

  const { data: files = [], isLoading } = useQuery<FileRecord[]>({
    queryKey: ["/api/files"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/files/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Delete failed");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "File deleted", description: "File removed successfully." });
    },
    onError: () => toast({ title: "Error", description: "Failed to delete file.", variant: "destructive" }),
  });

  const toggleVisibilityMutation = useMutation({
    mutationFn: async ({ id, isPublic }: { id: number; isPublic: boolean }) => {
      const res = await fetch(`/api/files/${id}/visibility`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isPublic }),
      });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/files"] }),
  });

  const handleFiles = (fileList: FileList) => {
    const file = fileList[0];
    if (!file) return;

    if (file.size > 500 * 1024 * 1024) {
      toast({ title: "File too large", description: "Maximum file size is 500 MB.", variant: "destructive" });
      return;
    }

    setUploadState({ file, progress: 0, status: "uploading" });

    const xhr = new XMLHttpRequest();
    const formData = new FormData();
    formData.append("file", file);

    xhr.upload.addEventListener("progress", e => {
      if (e.lengthComputable) {
        const pct = Math.round((e.loaded / e.total) * 100);
        setUploadState(prev => prev ? { ...prev, progress: pct } : null);
      }
    });

    xhr.addEventListener("load", () => {
      if (xhr.status === 201) {
        setUploadState(prev => prev ? { ...prev, progress: 100, status: "done" } : null);
        queryClient.invalidateQueries({ queryKey: ["/api/files"] });
        queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        toast({ title: "Upload complete!", description: `${file.name} uploaded successfully.` });
        setTimeout(() => setUploadState(null), 1500);
      } else {
        setUploadState(prev => prev ? { ...prev, status: "error" } : null);
        toast({ title: "Upload failed", description: "Please try again.", variant: "destructive" });
      }
    });

    xhr.addEventListener("error", () => {
      setUploadState(prev => prev ? { ...prev, status: "error" } : null);
    });

    xhr.open("POST", "/api/upload");
    xhr.send(formData);
  };

  const filtered = files.filter(f =>
    f.originalName.toLowerCase().includes(search.toLowerCase())
  );

  const totalSize = files.reduce((sum, f) => sum + f.size, 0);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />

      <main className="flex-1 overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 z-10 px-8 py-5 border-b border-border/50 bg-background/80 backdrop-blur-md flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Overview / Dashboard</p>
            <h1 className="text-xl font-bold text-foreground">My Files</h1>
          </div>
          <div className="relative">
            <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              data-testid="input-search"
              type="search"
              placeholder="Search files..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-10 pr-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/40 w-52 transition-all"
            />
          </div>
        </div>

        <div className="p-8 space-y-8">
          {/* Stats row */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: "Total Files", value: files.length, icon: "📁" },
              { label: "Storage Used", value: formatBytes(totalSize), icon: "💾" },
              { label: "Total Downloads", value: files.reduce((s, f) => s + f.downloadCount, 0), icon: "⬇️" },
            ].map((stat, i) => (
              <div key={i} data-testid={`card-stat-${i}`} className="glass rounded-2xl p-5">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-xl">{stat.icon}</span>
                  <p className="text-muted-foreground text-sm">{stat.label}</p>
                </div>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              </div>
            ))}
          </div>

          {/* Upload zone */}
          <div>
            <h2 className="text-base font-semibold text-foreground mb-4">Upload Files</h2>
            <DropZone onFilesSelected={handleFiles} />
          </div>

          {/* Files list */}
          <div>
            <h2 className="text-base font-semibold text-foreground mb-4">
              My Uploads
              {files.length > 0 && (
                <span className="ml-2 text-xs bg-white/5 text-muted-foreground px-2 py-0.5 rounded-full">
                  {filtered.length} files
                </span>
              )}
            </h2>

            {isLoading ? (
              <div className="flex items-center justify-center py-16">
                <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent spin-loader" />
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-16 glass rounded-2xl">
                <p className="text-4xl mb-3">📭</p>
                <p className="text-foreground font-medium">No files yet</p>
                <p className="text-muted-foreground text-sm mt-1">Upload your first file above</p>
              </div>
            ) : (
              <div className="space-y-2">
                {filtered.map(file => (
                  <div
                    key={file.id}
                    data-testid={`card-file-${file.id}`}
                    className="glass rounded-xl px-5 py-4 flex items-center gap-4 hover:bg-white/[0.06] transition-all group"
                  >
                    <span className="text-2xl flex-shrink-0">{getFileIcon(file.mimeType)}</span>

                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{file.originalName}</p>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-xs text-muted-foreground">{formatBytes(file.size)}</span>
                        <span className="text-muted-foreground/40">·</span>
                        <span className="text-xs text-muted-foreground">{formatDate(file.uploadedAt)}</span>
                        <span className="text-muted-foreground/40">·</span>
                        <span className="text-xs text-muted-foreground">{file.downloadCount} downloads</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all">
                      {/* Visibility toggle */}
                      <button
                        data-testid={`button-visibility-${file.id}`}
                        onClick={() => toggleVisibilityMutation.mutate({ id: file.id, isPublic: !file.isPublic })}
                        className={`text-xs px-2.5 py-1 rounded-lg border transition-all ${
                          file.isPublic
                            ? "bg-green-500/20 border-green-500/30 text-green-400"
                            : "bg-white/5 border-white/10 text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {file.isPublic ? "Public" : "Private"}
                      </button>

                      {/* Download */}
                      <a
                        href={`/api/files/${file.id}/download`}
                        data-testid={`button-download-${file.id}`}
                        className="p-2 rounded-lg bg-primary/20 hover:bg-primary/30 text-primary transition-all"
                        title="Download"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                        </svg>
                      </a>

                      {/* Delete */}
                      <button
                        data-testid={`button-delete-${file.id}`}
                        onClick={() => {
                          if (confirm("Delete this file?")) deleteMutation.mutate(file.id);
                        }}
                        className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-all"
                        title="Delete"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      {uploadState && (
        <UploadProgressCard state={uploadState} onClose={() => setUploadState(null)} />
      )}
    </div>
  );
}
