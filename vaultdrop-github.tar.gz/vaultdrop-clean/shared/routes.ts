import { z } from "zod";
import { registerSchema, loginSchema } from "./schema";

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  unauthorized: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  auth: {
    register: {
      method: "POST" as const,
      path: "/api/auth/register" as const,
      input: registerSchema,
      responses: { 201: z.any(), 400: errorSchemas.validation },
    },
    login: {
      method: "POST" as const,
      path: "/api/auth/login" as const,
      input: loginSchema,
      responses: { 200: z.any(), 401: errorSchemas.unauthorized },
    },
    logout: {
      method: "POST" as const,
      path: "/api/auth/logout" as const,
      responses: { 200: z.any() },
    },
    me: {
      method: "GET" as const,
      path: "/api/auth/me" as const,
      responses: { 200: z.any(), 401: errorSchemas.unauthorized },
    },
  },
  files: {
    upload: {
      method: "POST" as const,
      path: "/api/upload" as const,
      responses: { 201: z.any(), 400: errorSchemas.validation },
    },
    list: {
      method: "GET" as const,
      path: "/api/files" as const,
      responses: { 200: z.array(z.any()) },
    },
    download: {
      method: "GET" as const,
      path: "/api/files/:id/download" as const,
      responses: { 200: z.any(), 404: errorSchemas.notFound },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/files/:id" as const,
      responses: { 204: z.void(), 404: errorSchemas.notFound },
    },
    togglePublic: {
      method: "PATCH" as const,
      path: "/api/files/:id/visibility" as const,
      input: z.object({ isPublic: z.boolean() }),
      responses: { 200: z.any(), 404: errorSchemas.notFound },
    },
  },
  admin: {
    stats: {
      method: "GET" as const,
      path: "/api/admin/stats" as const,
      responses: { 200: z.any(), 403: errorSchemas.unauthorized },
    },
    users: {
      method: "GET" as const,
      path: "/api/admin/users" as const,
      responses: { 200: z.array(z.any()), 403: errorSchemas.unauthorized },
    },
    allFiles: {
      method: "GET" as const,
      path: "/api/admin/files" as const,
      responses: { 200: z.array(z.any()), 403: errorSchemas.unauthorized },
    },
    deleteUser: {
      method: "DELETE" as const,
      path: "/api/admin/users/:id" as const,
      responses: { 204: z.void(), 403: errorSchemas.unauthorized },
    },
    deleteFile: {
      method: "DELETE" as const,
      path: "/api/admin/files/:id" as const,
      responses: { 204: z.void(), 403: errorSchemas.unauthorized },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
