import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";
import {
  users, files,
  type User, type InsertUser,
  type FileRecord, type InsertFile,
  type SafeUser,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUsers(): Promise<SafeUser[]>;
  getUserById(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<SafeUser>;
  updateUserLastLogin(id: number): Promise<void>;
  updateUserStorage(id: number, delta: number): Promise<void>;
  deleteUser(id: number): Promise<void>;

  // Files
  getFilesByUserId(userId: number): Promise<FileRecord[]>;
  getAllFiles(): Promise<(FileRecord & { username: string })[]>;
  getFileById(id: number): Promise<FileRecord | undefined>;
  createFile(file: InsertFile): Promise<FileRecord>;
  deleteFile(id: number): Promise<void>;
  toggleFileVisibility(id: number, isPublic: boolean): Promise<FileRecord>;
  incrementDownloadCount(id: number): Promise<void>;

  // Stats
  getAdminStats(): Promise<{
    totalUsers: number;
    totalFiles: number;
    totalStorage: number;
    recentUploads: number;
  }>;
}

function sanitizeUser(user: User): SafeUser {
  const { passwordHash, ...safe } = user;
  return safe;
}

export class DatabaseStorage implements IStorage {
  async getUsers(): Promise<SafeUser[]> {
    const result = await db.select().from(users).orderBy(desc(users.createdAt));
    return result.map(sanitizeUser);
  }

  async getUserById(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<SafeUser> {
    const [created] = await db.insert(users).values(user).returning();
    return sanitizeUser(created);
  }

  async updateUserLastLogin(id: number): Promise<void> {
    await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, id));
  }

  async updateUserStorage(id: number, delta: number): Promise<void> {
    await db.update(users)
      .set({ storageUsed: sql`${users.storageUsed} + ${delta}` })
      .where(eq(users.id, id));
  }

  async deleteUser(id: number): Promise<void> {
    await db.delete(files).where(eq(files.userId, id));
    await db.delete(users).where(eq(users.id, id));
  }

  async getFilesByUserId(userId: number): Promise<FileRecord[]> {
    return await db.select().from(files).where(eq(files.userId, userId)).orderBy(desc(files.uploadedAt));
  }

  async getAllFiles(): Promise<(FileRecord & { username: string })[]> {
    const result = await db
      .select({
        id: files.id,
        userId: files.userId,
        filename: files.filename,
        originalName: files.originalName,
        size: files.size,
        mimeType: files.mimeType,
        path: files.path,
        isPublic: files.isPublic,
        downloadCount: files.downloadCount,
        uploadedAt: files.uploadedAt,
        username: users.username,
      })
      .from(files)
      .leftJoin(users, eq(files.userId, users.id))
      .orderBy(desc(files.uploadedAt));
    return result.map(r => ({ ...r, username: r.username ?? "unknown" }));
  }

  async getFileById(id: number): Promise<FileRecord | undefined> {
    const [file] = await db.select().from(files).where(eq(files.id, id));
    return file;
  }

  async createFile(file: InsertFile): Promise<FileRecord> {
    const [created] = await db.insert(files).values(file).returning();
    return created;
  }

  async deleteFile(id: number): Promise<void> {
    await db.delete(files).where(eq(files.id, id));
  }

  async toggleFileVisibility(id: number, isPublic: boolean): Promise<FileRecord> {
    const [updated] = await db.update(files).set({ isPublic }).where(eq(files.id, id)).returning();
    return updated;
  }

  async incrementDownloadCount(id: number): Promise<void> {
    await db.update(files)
      .set({ downloadCount: sql`${files.downloadCount} + 1` })
      .where(eq(files.id, id));
  }

  async getAdminStats(): Promise<{
    totalUsers: number;
    totalFiles: number;
    totalStorage: number;
    recentUploads: number;
  }> {
    const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const [fileCount] = await db.select({ count: sql<number>`count(*)` }).from(files);
    const [storageSum] = await db.select({ total: sql<number>`coalesce(sum(size), 0)` }).from(files);
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const [recentCount] = await db.select({ count: sql<number>`count(*)` }).from(files)
      .where(sql`${files.uploadedAt} > ${oneDayAgo}`);

    return {
      totalUsers: Number(userCount.count),
      totalFiles: Number(fileCount.count),
      totalStorage: Number(storageSum.total),
      recentUploads: Number(recentCount.count),
    };
  }
}

export const storage = new DatabaseStorage();
