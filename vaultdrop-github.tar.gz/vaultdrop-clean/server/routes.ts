import type { Express, Request, Response, NextFunction } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { registerSchema, loginSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import bcrypt from "bcryptjs";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { pool } from "./db";

const ADMIN_USERNAME = "zwedd";
const MAX_FILE_SIZE = 500 * 1024 * 1024; // 500MB
const UPLOADS_DIR = path.join(process.cwd(), "uploads");

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const multerStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const unique = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const ext = path.extname(file.originalname);
    cb(null, `${unique}${ext}`);
  },
});

const upload = multer({
  storage: multerStorage,
  limits: { fileSize: MAX_FILE_SIZE },
});

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session?.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session?.userId || req.session.userRole !== "admin") {
    return res.status(403).json({ message: "Forbidden" });
  }
  next();
}

declare module "express-session" {
  interface SessionData {
    userId: number;
    username: string;
    userRole: string;
  }
}

async function seedAdmin() {
  const existing = await storage.getUserByUsername(ADMIN_USERNAME);
  if (!existing) {
    const passwordHash = await bcrypt.hash("admin123", 10);
    await storage.createUser({
      username: ADMIN_USERNAME,
      email: "admin@zwedd.dev",
      passwordHash,
      role: "admin",
    });
    console.log(`[seed] Admin user '${ADMIN_USERNAME}' created.`);
  }
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  const PgSession = connectPgSimple(session);

  app.use(
    session({
      store: new PgSession({ pool, createTableIfMissing: true }),
      secret: process.env.SESSION_SECRET || "discord-upload-secret-key-2025",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: false,
        httpOnly: true,
        maxAge: 7 * 24 * 60 * 60 * 1000,
      },
    })
  );

  await seedAdmin();

  // ─── Auth Routes ───────────────────────────────────────────────────────────

  app.post("/api/auth/register", async (req, res) => {
    try {
      const input = registerSchema.parse(req.body);
      const existingEmail = await storage.getUserByEmail(input.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already in use" });
      }
      const existingUsername = await storage.getUserByUsername(input.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }
      const passwordHash = await bcrypt.hash(input.password, 10);
      const role = input.username === ADMIN_USERNAME ? "admin" : "user";
      const user = await storage.createUser({
        username: input.username,
        email: input.email,
        passwordHash,
        role,
      });
      req.session.userId = user.id;
      req.session.username = user.username;
      req.session.userRole = user.role;
      return res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const input = loginSchema.parse(req.body);
      const user = await storage.getUserByEmail(input.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      const valid = await bcrypt.compare(input.password, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      await storage.updateUserLastLogin(user.id);
      req.session.userId = user.id;
      req.session.username = user.username;
      req.session.userRole = user.role;
      const { passwordHash, ...safeUser } = user;
      return res.json(safeUser);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ message: "Logged out" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = await storage.getUserById(req.session.userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    const { passwordHash, ...safeUser } = user;
    return res.json(safeUser);
  });

  // ─── File Routes ───────────────────────────────────────────────────────────

  app.post("/api/upload", requireAuth, upload.single("file"), async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file provided" });
    }
    const fileRecord = await storage.createFile({
      userId: req.session.userId!,
      filename: req.file.filename,
      originalName: req.file.originalname,
      size: req.file.size,
      mimeType: req.file.mimetype,
      path: req.file.path,
      isPublic: false,
    });
    await storage.updateUserStorage(req.session.userId!, req.file.size);
    return res.status(201).json(fileRecord);
  });

  app.get("/api/files", requireAuth, async (req, res) => {
    const userFiles = await storage.getFilesByUserId(req.session.userId!);
    return res.json(userFiles);
  });

  app.get("/api/files/:id/download", requireAuth, async (req, res) => {
    const file = await storage.getFileById(Number(req.params.id));
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    if (file.userId !== req.session.userId && req.session.userRole !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    await storage.incrementDownloadCount(file.id);
    return res.download(file.path, file.originalName);
  });

  app.delete("/api/files/:id", requireAuth, async (req, res) => {
    const file = await storage.getFileById(Number(req.params.id));
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    if (file.userId !== req.session.userId && req.session.userRole !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    if (fs.existsSync(file.path)) {
      fs.unlinkSync(file.path);
    }
    await storage.updateUserStorage(file.userId, -file.size);
    await storage.deleteFile(file.id);
    return res.status(204).send();
  });

  app.patch("/api/files/:id/visibility", requireAuth, async (req, res) => {
    const file = await storage.getFileById(Number(req.params.id));
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    if (file.userId !== req.session.userId) {
      return res.status(403).json({ message: "Forbidden" });
    }
    const { isPublic } = z.object({ isPublic: z.boolean() }).parse(req.body);
    const updated = await storage.toggleFileVisibility(file.id, isPublic);
    return res.json(updated);
  });

  // ─── Admin Routes ──────────────────────────────────────────────────────────

  app.get("/api/admin/stats", requireAdmin, async (_req, res) => {
    const stats = await storage.getAdminStats();
    return res.json(stats);
  });

  app.get("/api/admin/users", requireAdmin, async (_req, res) => {
    const allUsers = await storage.getUsers();
    return res.json(allUsers);
  });

  app.get("/api/admin/files", requireAdmin, async (_req, res) => {
    const allFiles = await storage.getAllFiles();
    return res.json(allFiles);
  });

  app.delete("/api/admin/users/:id", requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const user = await storage.getUserById(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    const userFiles = await storage.getFilesByUserId(id);
    for (const file of userFiles) {
      if (fs.existsSync(file.path)) fs.unlinkSync(file.path);
    }
    await storage.deleteUser(id);
    return res.status(204).send();
  });

  app.delete("/api/admin/files/:id", requireAdmin, async (req, res) => {
    const file = await storage.getFileById(Number(req.params.id));
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    if (fs.existsSync(file.path)) fs.unlinkSync(file.path);
    await storage.updateUserStorage(file.userId, -file.size);
    await storage.deleteFile(file.id);
    return res.status(204).send();
  });

  return httpServer;
}
