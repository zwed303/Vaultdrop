# VaultDrop

A fast, modern file upload platform with user accounts, real-time upload progress, and an admin panel.

## Features

- Upload files up to 500MB with live progress tracking
- User registration and login (session-based auth)
- My Files panel — download, delete, public/private toggle
- Admin panel — manage users, view all files, platform statistics
- Dark glassmorphism UI

## Tech Stack

- **Frontend:** React, TailwindCSS, TanStack Query, Wouter
- **Backend:** Node.js, Express, TypeScript
- **Database:** PostgreSQL, Drizzle ORM
- **Auth:** express-session, bcryptjs
- **File uploads:** Multer

## Getting Started

### 1. Clone and install

```bash
git clone https://github.com/yourusername/vaultdrop.git
cd vaultdrop
npm install
```

### 2. Set up environment variables

```bash
cp .env.example .env
```

Edit `.env` with your database connection string and a secret key.

### 3. Push the database schema

```bash
npm run db:push
```

### 4. Run in development

```bash
npm run dev
```

Open [http://localhost:5000](http://localhost:5000)

## Admin Account

On first startup, an admin account is created automatically:

- **Username:** zwedd
- **Email:** admin@zwedd.dev
- **Password:** admin123

> Change the password after first login.

## Production Build

```bash
npm run build
npm start
```

## Deployment

Works on any Node.js host (Railway, Render, VPS, etc.).

Required environment variables:
- `DATABASE_URL` — PostgreSQL connection string
- `SESSION_SECRET` — A long random string
- `PORT` — Port to listen on (default: 5000)

Uploaded files are stored in the `uploads/` directory on the server.
